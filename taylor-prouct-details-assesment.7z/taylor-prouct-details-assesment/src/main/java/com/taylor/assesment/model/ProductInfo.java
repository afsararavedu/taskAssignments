package com.taylor.assesment.model;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class ProductInfo {
	
	String countryCode;
	List<Product> productlist;
	
	public ProductInfo(String countryCode, List<Product> productlist) {
		super();
		this.countryCode = countryCode;
		this.productlist = productlist;
	}
	public ProductInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public List<Product> getProductlist() {
		return productlist;
	}
	public void setProductlist(List<Product> productlist) {
		this.productlist = productlist;
	}
	
	

}
