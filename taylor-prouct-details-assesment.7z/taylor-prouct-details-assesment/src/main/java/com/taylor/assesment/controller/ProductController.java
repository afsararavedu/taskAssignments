package com.taylor.assesment.controller;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.taylor.assesment.model.Product;
import com.taylor.assesment.service.ProductService;

@RestController
public class ProductController {

	
	
	private static final String String = null;
	@Autowired
	ProductService productService;
	
	
	
	
	@RequestMapping("/taylor/getProductList")
	public List<Product> getProductDetail() {

		List<Product> productList = new ArrayList<>();
		System.out.println("-----getProductDetailWithContryCode -----");

		try {
			productList = productService.getAllProductList();
			
			System.out.println("-----getAllProductList ---productList--"+ productList);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return productList;
	}
	
	@RequestMapping("/taylor/getProductListByCountryCode/{countryCode}")
	@ResponseBody
	public List<Product> getProductDetailWithContryCode(@PathVariable ("countryCode") String countryCode) {

		List<Product> productList = new ArrayList<>();
		
		System.out.println("-----getProductDetailWithContryCode -----");

		try {
			productList = productService.getProductListWithCountryCurrency(countryCode);
			
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

		return productList;
	}

}
