package com.taylor.assesment.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.taylor.assesment.model.CurrencyConverter;
import com.taylor.assesment.model.Product;
import com.taylor.assesment.model.ProductInfo;

@Component
public class ProductService {

	String fixerApi = "http://data.fixer.io/api/latest?access_key=d2515388ae49abef4d6747c44dce5184";

	List<Product> productList = new ArrayList<>();

	public List<Product> getProductListWithCountryCurrency(String countryCode) throws MalformedURLException {

		System.out.println("countryCode : " + countryCode);

		ProductInfo productInfo = null;
		URL urlForGetRequest = new URL("http://data.fixer.io/api/latest?access_key=d2515388ae49abef4d6747c44dce5184");

		String readLine = null;
		HttpURLConnection conection;
		try {
			conection = (HttpURLConnection) urlForGetRequest.openConnection();
			conection.setRequestMethod("GET");
			int responseCode = conection.getResponseCode();

			StringBuffer response = new StringBuffer();

			if (responseCode == HttpURLConnection.HTTP_OK) {
				BufferedReader in = new BufferedReader(new InputStreamReader(conection.getInputStream()));
				while ((readLine = in.readLine()) != null) {

					response.append(readLine);
				}
				in.close();
			} else {
				System.out.println("GET NOT WORKED with response code" + responseCode);
			}

			CurrencyConverter currencyConverter = new ObjectMapper().readValue(response.toString(),
					CurrencyConverter.class);

			System.out.println("currencyConverter.getRates() value " + currencyConverter.getRates().get(countryCode));

			if (currencyConverter.getRates().get(countryCode) == null) {

				throw new Exception("country code is not available , please try with correct one");
			}

			/**
			 * Read object from file
			 */

			try {
				ObjectMapper mapper = new ObjectMapper();
				productInfo = mapper.readValue(new File("src/main/resources/mockdata.json"), ProductInfo.class);
			} catch (Exception e) {
				e.printStackTrace();
			}

			Float baseprice = currencyConverter.getRates().get(countryCode);
			System.out.println("country currency value from  fixer.io  data:  " + baseprice);

			for (Product product : productInfo.getProductlist()) {
				// Setting price with requested currency
				float bestprice = product.getPrice() * baseprice;
				System.out.println("bestprice " + bestprice);

				product.setCountryCode(countryCode);
				product.setBasePrice(product.getPrice());
				product.setPrice(bestprice);

			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception : " + e); // here printing full error message
		}

		return productInfo.getProductlist();

	}

	public List<Product> getAllProductList() {

		ProductInfo productInfo = null;
		try {

			ObjectMapper mapper = new ObjectMapper();

			/**
			 * Read mockdata from json file
			 */
			try {
				productInfo = mapper.readValue(new File("src/main/resources/mockdata.json"), ProductInfo.class);

				if (productInfo.getCountryCode() == null) {

					for (Product product : productInfo.getProductlist()) {

						product.setCountryCode("EUR");
						product.setBasePrice(product.getPrice());

					}

				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception : " + e); // here printing full error message
		}
		return productInfo.getProductlist();

	}

}
