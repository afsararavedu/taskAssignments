package com.taylor.assesment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaylorProuctDetailsAssesmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaylorProuctDetailsAssesmentApplication.class, args);
	}

}
